#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Employee {
    int id;
    char name[50];
    char dept[30];
    char desig[30];
    float basic, hra, da, travel, other_allow;
    float pf, ptax, itax, other_ded;
    float gross, total_ded, net;
};

struct Employee *emp = NULL;
int count = 0;
int capacity = 0;

float calcTax(float gross)
{
    if (gross <= 25000)
        return 0;
    else if (gross <= 50000)
        return gross * 0.05;
    else if (gross <= 100000)
        return gross * 0.10;
    else
        return gross * 0.20;
}

void calcSalary(struct Employee *e)
{
    e->hra = e->basic * 0.20;
    e->da = e->basic * 0.10;
    e->pf = e->basic * 0.12;
    e->ptax = 200;
    e->gross = e->basic + e->hra + e->da + e->travel + e->other_allow;
    e->itax = calcTax(e->gross);
    e->total_ded = e->pf + e->ptax + e->itax + e->other_ded;
    e->net = e->gross - e->total_ded;
}

int findEmployee(int id)
{
    int i;
    for (i = 0; i < count; i++) {
        if ((emp + i)->id == id)
            return i;
    }
    return -1;
}

void growArray()
{
    struct Employee *temp;
    if (capacity == 0)
        capacity = 5;
    else
        capacity = capacity * 2;
    temp = (struct Employee *)realloc(emp, capacity * sizeof(struct Employee));
    if (temp == NULL) {
        printf("Memory allocation failed\n");
        free(emp);
        exit(1);
    }
    emp = temp;
}

float readPositive(char *msg)
{
    float x;
    while (1) {
        printf("%s", msg);
        if (scanf("%f", &x) == 1 && x >= 0)
            return x;
        printf("Enter a valid number (0 or more)\n");
        while (getchar() != '\n');
    }
}

void addEmployee()
{
    int id;
    struct Employee *e;

    printf("Enter employee ID: ");
    if (scanf("%d", &id) != 1 || id <= 0) {
        printf("Invalid ID\n");
        while (getchar() != '\n');
        return;
    }
    if (findEmployee(id) != -1) {
        printf("This ID already exists\n");
        return;
    }
    if (count == capacity)
        growArray();

    e = emp + count;
    memset(e, 0, sizeof(struct Employee));
    e->id = id;
    printf("Enter name: ");
    scanf(" %[^\n]", e->name);
    printf("Enter department: ");
    scanf(" %[^\n]", e->dept);
    printf("Enter designation: ");
    scanf(" %[^\n]", e->desig);
    e->basic = readPositive("Enter basic salary: ");
    e->travel = readPositive("Enter travel allowance: ");
    e->other_allow = readPositive("Enter other allowance: ");
    e->other_ded = readPositive("Enter other deductions: ");

    calcSalary(e);
    count++;
    printf("Employee added successfully\n");
}

void displayAll()
{
    int i;
    if (count == 0) {
        printf("No employees found\n");
        return;
    }
    printf("\n%-6s %-20s %-15s %-10s %-10s %-10s\n", "ID", "Name", "Department", "Gross", "Deduct", "Net");
    printf("-----------------------------------------------------------------------------\n");
    for (i = 0; i < count; i++) {
        struct Employee *e = emp + i;
        printf("%-6d %-20s %-15s %-10.2f %-10.2f %-10.2f\n", e->id, e->name, e->dept, e->gross, e->total_ded, e->net);
    }
}

void searchEmployee()
{
    int id, pos;
    printf("Enter employee ID to search: ");
    scanf("%d", &id);
    pos = findEmployee(id);
    if (pos == -1) {
        printf("Employee not found\n");
        return;
    }
    struct Employee *e = emp + pos;
    printf("\nID: %d\nName: %s\nDepartment: %s\nDesignation: %s\n", e->id, e->name, e->dept, e->desig);
    printf("Basic: %.2f\nGross: %.2f\nDeductions: %.2f\nNet: %.2f\n", e->basic, e->gross, e->total_ded, e->net);
}

void updateEmployee()
{
    int id, pos;
    printf("Enter employee ID to update: ");
    scanf("%d", &id);
    pos = findEmployee(id);
    if (pos == -1) {
        printf("Employee not found\n");
        return;
    }
    struct Employee *e = emp + pos;
    e->basic = readPositive("Enter new basic salary: ");
    e->travel = readPositive("Enter new travel allowance: ");
    e->other_allow = readPositive("Enter new other allowance: ");
    e->other_ded = readPositive("Enter new other deductions: ");
    calcSalary(e);
    printf("Employee updated successfully\n");
}

void deleteEmployee()
{
    int id, pos, i;
    printf("Enter employee ID to delete: ");
    scanf("%d", &id);
    pos = findEmployee(id);
    if (pos == -1) {
        printf("Employee not found\n");
        return;
    }
    for (i = pos; i < count - 1; i++)
        *(emp + i) = *(emp + i + 1);
    count--;
    printf("Employee deleted successfully\n");
}

void salarySlip()
{
    int id, pos;
    printf("Enter employee ID: ");
    scanf("%d", &id);
    pos = findEmployee(id);
    if (pos == -1) {
        printf("Employee not found\n");
        return;
    }
    struct Employee *e = emp + pos;
    printf("\n================ SALARY SLIP ================\n");
    printf("Employee ID   : %d\n", e->id);
    printf("Name          : %s\n", e->name);
    printf("Department    : %s\n", e->dept);
    printf("Designation   : %s\n", e->desig);
    printf("---------------------------------------------\n");
    printf("EARNINGS\n");
    printf("  Basic Pay         : %10.2f\n", e->basic);
    printf("  HRA (20%%)         : %10.2f\n", e->hra);
    printf("  DA (10%%)          : %10.2f\n", e->da);
    printf("  Travel Allowance  : %10.2f\n", e->travel);
    printf("  Other Allowance   : %10.2f\n", e->other_allow);
    printf("  Gross Salary      : %10.2f\n", e->gross);
    printf("---------------------------------------------\n");
    printf("DEDUCTIONS\n");
    printf("  Provident Fund    : %10.2f\n", e->pf);
    printf("  Professional Tax  : %10.2f\n", e->ptax);
    printf("  Income Tax        : %10.2f\n", e->itax);
    printf("  Other Deductions  : %10.2f\n", e->other_ded);
    printf("  Total Deductions  : %10.2f\n", e->total_ded);
    printf("---------------------------------------------\n");
    printf("NET SALARY          : %10.2f\n", e->net);
    printf("=============================================\n");
    if (e->net < 0)
        printf("Warning: deductions are more than earnings\n");
}

void summary()
{
    int i, maxi = 0, mini = 0;
    float tg = 0, td = 0, tn = 0;

    if (count == 0) {
        printf("No employees found\n");
        return;
    }
    for (i = 0; i < count; i++) {
        struct Employee *e = emp + i;
        tg += e->gross;
        td += e->total_ded;
        tn += e->net;
        if (e->net > (emp + maxi)->net)
            maxi = i;
        if (e->net < (emp + mini)->net)
            mini = i;
    }
    printf("\n========== FINANCIAL SUMMARY ==========\n");
    printf("Total employees     : %d\n", count);
    printf("Total gross salary  : %.2f\n", tg);
    printf("Total deductions    : %.2f\n", td);
    printf("Total net payout    : %.2f\n", tn);
    printf("Average net salary  : %.2f\n", tn / count);
    printf("Highest net salary  : %.2f (%s)\n", (emp + maxi)->net, (emp + maxi)->name);
    printf("Lowest net salary   : %.2f (%s)\n", (emp + mini)->net, (emp + mini)->name);
    printf("=======================================\n");
}

void sortEmployees()
{
    int i, j, choice;
    struct Employee temp;

    if (count < 2) {
        printf("Not enough employees to sort\n");
        return;
    }
    printf("1. Sort by ID\n2. Sort by name\n3. Sort by net salary\nEnter choice: ");
    scanf("%d", &choice);
    for (i = 0; i < count - 1; i++) {
        for (j = 0; j < count - i - 1; j++) {
            int swap = 0;
            if (choice == 1 && (emp + j)->id > (emp + j + 1)->id)
                swap = 1;
            else if (choice == 2 && strcmp((emp + j)->name, (emp + j + 1)->name) > 0)
                swap = 1;
            else if (choice == 3 && (emp + j)->net < (emp + j + 1)->net)
                swap = 1;
            if (swap) {
                temp = *(emp + j);
                *(emp + j) = *(emp + j + 1);
                *(emp + j + 1) = temp;
            }
        }
    }
    printf("Employees sorted\n");
    displayAll();
}

int main()
{
    int choice;

    do {
        printf("\n===== EMPLOYEE PAYROLL MANAGEMENT SYSTEM =====\n");
        printf("1. Add Employee\n");
        printf("2. View All Employees\n");
        printf("3. Search Employee\n");
        printf("4. Update Employee\n");
        printf("5. Delete Employee\n");
        printf("6. Generate Salary Slip\n");
        printf("7. Financial Summary\n");
        printf("8. Sort Employees\n");
        printf("0. Exit\n");
        printf("Enter your choice: ");
        if (scanf("%d", &choice) != 1) {
            printf("Invalid input\n");
            while (getchar() != '\n');
            choice = -1;
            continue;
        }

        switch (choice) {
            case 1: addEmployee(); break;
            case 2: displayAll(); break;
            case 3: searchEmployee(); break;
            case 4: updateEmployee(); break;
            case 5: deleteEmployee(); break;
            case 6: salarySlip(); break;
            case 7: summary(); break;
            case 8: sortEmployees(); break;
            case 0: printf("Exiting program\n"); break;
            default: printf("Invalid choice\n");
        }
    } while (choice != 0);

    free(emp);
    return 0;
}